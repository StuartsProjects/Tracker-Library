var searchData=
[
  ['name',['name',['../structdirectory_entry.html#a05dc993ea55a1a742de5970541a31ecb',1,'directoryEntry']]],
  ['name1',['name1',['../structlong_directory_entry.html#a629f1ca5ba2ccce6cac5295578b6e7b4',1,'longDirectoryEntry']]],
  ['name2',['name2',['../structlong_directory_entry.html#ad763b5a3da4b8d326d9888493fbb819a',1,'longDirectoryEntry']]],
  ['name3',['name3',['../structlong_directory_entry.html#a6f14c81b7d224dc4431217f92601257a',1,'longDirectoryEntry']]],
  ['nextfree',['nextFree',['../structfat32__fsinfo.html#a539b3bb0a2ead9df417df9ac8b6b1606',1,'fat32_fsinfo']]]
];
